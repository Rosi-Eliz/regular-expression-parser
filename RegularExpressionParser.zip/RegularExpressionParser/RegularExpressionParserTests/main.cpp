//
//  main.cpp
//  RegularExpressionParserTests
//
//  Created by Rosi-Eliz Dzhurkova on 28.08.20.
//  Copyright © 2020 Rosi-Eliz Dzhurkova. All rights reserved.
//

#define CATCH_CONFIG_MAIN  // This tells Catch to provide a main()
#include "catch.hh"
