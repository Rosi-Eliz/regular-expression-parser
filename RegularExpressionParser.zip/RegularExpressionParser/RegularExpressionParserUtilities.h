//
//  RegularExpressionParserUtilities.h
//  RegularExpressionParser
//
//  Created by Rosi-Eliz Dzhurkova on 03.09.20.
//  Copyright © 2020 Rosi-Eliz Dzhurkova. All rights reserved.
//

#ifndef RegularExpressionParserUtilities_h
#define RegularExpressionParserUtilities_h
#include "FiniteAutomation.h"

using namespace std;

class RegularExpressionParserUtilities {
public:
    static void connectStates(State* fromState, State* toState);
    static StatesPair baseStone(string symbol, FiniteAutomation* automation);
    static State* conjunction(State* currentState, string first, string second, FiniteAutomation* automation);
    static State* disjunction(State* currentState, string first, string second, FiniteAutomation* automation);
    static State* asterisk(State* currentState, string word, FiniteAutomation* automation);
    static State* plus(State* currentState, string word, FiniteAutomation* automation);
};


void RegularExpressionParserUtilities::connectStates(State* fromState, State* toState)
{
    Edge* connectingEdge = new Edge(string(1, EPSILON), toState);
    fromState->setOutboundTransition(connectingEdge);
}

StatesPair RegularExpressionParserUtilities::baseStone(string symbol, FiniteAutomation* automation)
{
    State* initialState = new State(false, false, automation);
    State* finalState = new State(false, false, automation);
    State* symbolStartState = new State(false, false, automation);
    State* symbolEndState = new State(false, false, automation);
    Edge* inboundEpsilonTransition = new Edge(string(1, EPSILON), symbolStartState);
    Edge* outboundEpsilonTransition = new Edge(string(1, EPSILON), finalState);
    Edge* symbolEdge = new Edge(symbol, symbolEndState);
    initialState->setOutboundTransition(inboundEpsilonTransition);
    symbolStartState->setOutboundTransition(symbolEdge);
    symbolEndState->setOutboundTransition(outboundEpsilonTransition);
    
    return StatesPair(initialState, finalState);
}


State* RegularExpressionParserUtilities::conjunction(State* currentState, string first, string second, FiniteAutomation* automation)
{
    StatesPair firstStonePair = baseStone(first, automation);
    Edge* initialConnectingEdge = new Edge(string(1, EPSILON), firstStonePair.initialState);
    currentState->setOutboundTransition(initialConnectingEdge);
    
    StatesPair secondStonePair = baseStone(second, automation);
    connectStates(firstStonePair.finalState, secondStonePair.initialState);
    
    return secondStonePair.finalState;
}

State* RegularExpressionParserUtilities::disjunction(State* currentState, string first, string second, FiniteAutomation* automation){
    StatesPair firstStonePair = baseStone(first, automation);
    State* firstStoneInitialState = firstStonePair.initialState;
    State* firstStoneFinalState = firstStonePair.finalState;
    
    StatesPair secondStonePair = baseStone(second, automation);
    State* secondStoneInitialState = secondStonePair.initialState;
    State* secondStoneFinalState = secondStonePair.finalState;
    
    State* connectingState = new State(false, false, automation);
    Edge* connectingEdge = new Edge(string(1, EPSILON), connectingState);
    currentState->setOutboundTransition(connectingEdge);
    
    Edge* firstEpsilonTransition = new Edge (string(1, EPSILON), firstStoneInitialState);
    Edge* secondEpsilonTransition = new Edge(string(1, EPSILON), secondStoneInitialState);
    connectingState->setOutboundTransition(firstEpsilonTransition);
    connectingState->setOutboundTransition(secondEpsilonTransition);
    
    State* connectingFinalState = new State(false, false, automation);
    Edge* firstFinalTransition = new Edge(string(1, EPSILON), connectingFinalState);
    Edge* secondFinalTransition = new Edge(string(1, EPSILON), connectingFinalState);
    firstStoneFinalState->setOutboundTransition(firstFinalTransition);
    secondStoneFinalState->setOutboundTransition(secondFinalTransition);
    
    State* finalState = new State(false, false, automation);
    Edge* finalTransition = new Edge(string(1, EPSILON), finalState);
    connectingFinalState->setOutboundTransition(finalTransition);
    
    return finalState;
}

State* RegularExpressionParserUtilities::asterisk(State* currentState, string word, FiniteAutomation* automation){
    
    StatesPair pair = baseStone(word, automation);
    State* symbolInitialState = pair.initialState;
    State* symbolFinalState = pair.finalState;
    
    Edge* connectingEdge = new Edge(string(1, EPSILON), symbolInitialState);
    currentState->setOutboundTransition(connectingEdge);
    
    Edge* returnEdge = new Edge(string(1, EPSILON), symbolInitialState);
    symbolFinalState->setOutboundTransition(returnEdge);
    Edge* skipEdge = new Edge(string(1, EPSILON), symbolFinalState);
    symbolInitialState->setOutboundTransition(skipEdge);

    State* finalState = new State(false, false, automation);
    Edge* finalEdge = new Edge(string(1, EPSILON), finalState);
    symbolFinalState->setOutboundTransition(finalEdge);
    
    return finalState;
}

State* RegularExpressionParserUtilities::plus(State* currentState, string word, FiniteAutomation* automation){
    
    StatesPair pair = baseStone(word, automation);
    State* symbolInitialState = pair.initialState;
    State* symbolFinalState = pair.finalState;
    
    Edge* connectingEdge = new Edge(string(1, EPSILON), symbolInitialState);
    currentState->setOutboundTransition(connectingEdge);
    
    Edge* returnEdge = new Edge(string(1, EPSILON), symbolInitialState);
    symbolFinalState->setOutboundTransition(returnEdge);
    
    State* finalState = new State(false, false, automation);
    Edge* finalEdge = new Edge(string(1, EPSILON), finalState);
    symbolFinalState->setOutboundTransition(finalEdge);
    
    return finalState;
}

#endif /* RegularExpressionParserUtilities_h */
